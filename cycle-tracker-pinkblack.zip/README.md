
# Cycle Tracker (Pink & Black Demo)

Mobile‑first front‑end demo for tracking weight, mood, symptoms, water, stress, sleep – then visualising **overlaid cycles** and a **symptom heatmap** by phase.

## Pages
- `index.html` — Dashboard (chart + recent entries)
- `log.html` — Daily entry form
- `reports.html` — Weight overlay + symptom heatmap
- `settings.html` — Period start & cycle length (phase preview)

## Tech
- Vanilla HTML/CSS/JS
- Chart.js via CDN
- LocalStorage for demo (swap to Firebase or your backend later)

## Run
Just open `index.html` locally or push to GitHub Pages.
