
// Pink/Black Cycle Tracker demo — localStorage-based. DB-ready structure.
const App = (() => {
  const STORAGE_KEY = 'cycle_entries_v2';
  const SETTINGS_KEY = 'cycle_settings_v1';
  const cycleColors = ['#ff4da6','#00e5ff','#22c55e','#ffb703','#9b5de5','#ff006e','#3a86ff','#fb5607'];

  function getEntries(){ return JSON.parse(localStorage.getItem(STORAGE_KEY)||'[]'); }
  function setEntries(arr){ localStorage.setItem(STORAGE_KEY, JSON.stringify(arr)); }

  function getSettings(){ 
    return JSON.parse(localStorage.getItem(SETTINGS_KEY) || '{"cycleLength":28}'); 
  }
  function setSettings(s){ localStorage.setItem(SETTINGS_KEY, JSON.stringify(s)); }

  // ===== Dash =====
  function initDashboard(){
    renderWeightChart('weightChart');
    renderRecentTable('recentTable');
  }

  function renderRecentTable(tableId){
    const tbody = document.querySelector(`#${tableId} tbody`);
    const rows = getEntries().slice(-10).reverse();
    tbody.innerHTML = rows.map(e => {
      const cd = `${e.cycleNumber || '?'}·${e.cycleDay || '?'}`;
      return `<tr><td>${e.date||''}</td><td>${cd}</td><td>${e.weight||''}</td><td>${e.mood||''}</td></tr>`;
    }).join('') || `<tr><td colspan="4" class="small">No entries yet. Add one on the Log page.</td></tr>`;
  }

  // ===== Log =====
  function initLog(){
    const form = document.getElementById('logForm');
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const fd = new FormData(form);
      const entry = Object.fromEntries(fd.entries());
      const arr = getEntries(); 
      arr.push(entry); 
      setEntries(arr);
      form.reset();
      alert('Saved!');
    });
  }

  // ===== Reports =====
  function initReports(){
    renderWeightChart('weightChart');
    renderHeatmap('heatmap');
  }

  function renderWeightChart(canvasId){
    const entries = getEntries();
    const cycles = {};
    entries.forEach(e => {
      const c = e.cycleNumber || '1';
      (cycles[c] ||= []).push({x: Number(e.cycleDay), y: Number(e.weight)});
    });
    const datasets = Object.keys(cycles).sort((a,b)=>Number(a)-Number(b)).map((c,i)=>{
      const pts = cycles[c].filter(p=>!Number.isNaN(p.x)&&!Number.isNaN(p.y)).sort((a,b)=>a.x-b.x);
      return {
        label: `Cycle ${c}`,
        data: pts,
        borderColor: cycleColors[i % cycleColors.length],
        backgroundColor: cycleColors[i % cycleColors.length],
        tension: .35,
        borderWidth: 3,
        pointRadius: 4,
        pointHoverRadius: 6,
        fill: false,
        parsing:false
      };
    });

    const ctx = document.getElementById(canvasId).getContext('2d');
    if(ctx._chart) ctx._chart.destroy();
    ctx._chart = new Chart(ctx, {
      type: 'line',
      data: { datasets },
      options: {
        responsive:true,
        plugins:{
          legend:{ labels:{ usePointStyle:true } },
          title:{ display:true, text:'Weight overlay by cycle day' }
        },
        scales:{
          x:{ type:'linear', min:1, max:35, title:{display:true,text:'Cycle Day'} },
          y:{ title:{display:true,text:'Weight (kg)'} }
        }
      }
    });
  }

  function phaseForDay(day, cycleLength=28){
    // Simple heuristic windows
    if(day <= 5) return 'Menstrual';
    if(day <= (cycleLength/2 - 2)) return 'Follicular';
    if(day <= (cycleLength/2 + 2)) return 'Ovulation';
    return 'Luteal';
  }

  function renderHeatmap(canvasId){
    // Build phase x symptom counts from entries
    const entries = getEntries();
    const settings = getSettings();
    const phases = ['Menstrual','Follicular','Ovulation','Luteal'];
    const symptoms = ['Cramps','Bloating','Tender Breasts','Headache','Acne'];
    const counts = Object.fromEntries(phases.map(p=>[p,Object.fromEntries(symptoms.map(s=>[s,0]))]));

    entries.forEach(e=>{
      const d = Number(e.cycleDay);
      const s = e.symptom;
      if(!Number.isNaN(d) && s){
        const ph = phaseForDay(d, settings.cycleLength||28);
        counts[ph][s]++;
      }
    });

    // Convert to stacked bar per phase
    const labels = phases;
    const datasets = symptoms.map((s,i)=> ({
      label: s,
      data: labels.map(p=>counts[p][s]),
      backgroundColor: cycleColors[(i+2)%cycleColors.length],
      borderWidth:0,
      borderSkipped:false
    }));

    const ctx = document.getElementById(canvasId).getContext('2d');
    if(ctx._chart) ctx._chart.destroy();
    ctx._chart = new Chart(ctx, {
      type:'bar',
      data:{ labels, datasets },
      options:{
        responsive:true,
        indexAxis:'y',
        plugins:{ title:{display:true,text:'Symptom frequency by phase'}, legend:{position:'bottom'} },
        scales:{ x:{ stacked:true }, y:{ stacked:true } }
      }
    });
  }

  // ===== Settings =====
  function initSettings(){
    const form = document.getElementById('settingsForm');
    const s = getSettings();
    if(s.periodStart) form.periodStart.value = s.periodStart;
    if(s.cycleLength) form.cycleLength.value = s.cycleLength;
    updatePreview();
    form.addEventListener('submit',(e)=>{
      e.preventDefault();
      const fd = new FormData(form);
      const cfg = Object.fromEntries(fd.entries());
      cfg.cycleLength = Number(cfg.cycleLength);
      setSettings(cfg);
      updatePreview();
      alert('Settings saved');
    });
  }

  function updatePreview(){
    const s = getSettings();
    const len = s.cycleLength || 28;
    const preview = `Menstrual: days 1–5 · Follicular: 6–${Math.floor(len/2-2)} · Ovulation: ~${Math.floor(len/2-2)}–${Math.ceil(len/2+2)} · Luteal: ${Math.ceil(len/2+3)}–${len}`;
    const el = document.getElementById('phasePreview');
    if(el) el.textContent = preview;
  }

  return { initDashboard, initLog, initReports, initSettings };
})();
